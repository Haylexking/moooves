"use client"

import { TournamentDashboard } from "@/components/tournament/tournament-dashboard"

export default function TournamentsPage() {
  return <TournamentDashboard />
}
