"use client"

import { OfflineGameSetup } from "@/components/offline/offline-game-setup"

export default function OfflinePage() {
  return <OfflineGameSetup />
}
